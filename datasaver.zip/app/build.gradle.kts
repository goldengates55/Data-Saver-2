plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.datasaver"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.datasaver"
        minSdk = 29          // NetworkStatsManager works reliably without phone-state permission from Android 10
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

// No dependencies on purpose: plain Android views, no Compose/AppCompat.
// This keeps the APK in the low single-digit MB, cheap to download and share.
