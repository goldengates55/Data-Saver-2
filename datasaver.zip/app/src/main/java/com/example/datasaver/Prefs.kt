package com.example.datasaver

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("datasaver", Context.MODE_PRIVATE)

    fun blocked(c: Context): Set<String> =
        sp(c).getStringSet("blocked", emptySet()) ?: emptySet()

    fun setBlocked(c: Context, pkg: String, on: Boolean) {
        val s = blocked(c).toMutableSet()
        if (on) s.add(pkg) else s.remove(pkg)
        sp(c).edit().putStringSet("blocked", s).apply()
    }

    fun isBlockingOn(c: Context): Boolean = sp(c).getBoolean("blocking_on", false)

    fun setBlockingOn(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("blocking_on", on).apply()
    }

    /** true = chosen apps are cut off only on mobile data and work normally on Wi-Fi. */
    fun mobileOnly(c: Context): Boolean = sp(c).getBoolean("mobile_only", true)

    fun setMobileOnly(c: Context, on: Boolean) {
        sp(c).edit().putBoolean("mobile_only", on).apply()
    }
}
