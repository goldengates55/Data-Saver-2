package com.example.datasaver

import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

/**
 * Per-app blocking with a local VPN.
 *
 * Only the apps the user chose to block are routed into the tunnel (addAllowedApplication).
 * Every packet they send is read and discarded, so those apps get no connection.
 * All other apps bypass the tunnel and use the network normally.
 * Nothing leaves the phone; there is no server.
 *
 * v0.2: with "mobile only" on (the default), the tunnel is closed while the phone is on Wi-Fi,
 * so the chosen apps work normally there, and it is opened again on mobile data.
 */
class BlockerVpnService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var drainThread: Thread? = null
    private var cm: ConnectivityManager? = null
    private var netCallback: ConnectivityManager.NetworkCallback? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }
        if (Prefs.blocked(this).isEmpty()) {
            shutdown()
            return START_NOT_STICKY
        }
        registerNetworkCallback()
        teardown()      // rebuild from scratch so a changed app list takes effect
        refresh()
        return if (Prefs.isBlockingOn(this)) START_STICKY else START_NOT_STICKY
    }

    /** Opens or closes the tunnel depending on the settings and the current network. */
    private fun refresh() {
        val shouldBlock = !(Prefs.mobileOnly(this) && onWifi())
        if (shouldBlock) {
            if (tun == null && !establishTunnel()) shutdown()
        } else {
            teardown()
        }
    }

    private fun onWifi(): Boolean {
        val c = cm ?: return false
        val caps = c.getNetworkCapabilities(c.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun registerNetworkCallback() {
        if (netCallback != null) return
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        cm = manager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { onNetworkChanged() }
            override fun onLost(network: Network) { onNetworkChanged() }
            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                onNetworkChanged()
            }
        }
        netCallback = cb
        manager.registerDefaultNetworkCallback(cb)
    }

    private fun unregisterNetworkCallback() {
        val cb = netCallback ?: return
        try { cm?.unregisterNetworkCallback(cb) } catch (e: Exception) { }
        netCallback = null
    }

    private fun onNetworkChanged() {
        main.post { if (Prefs.isBlockingOn(this)) refresh() }
    }

    private fun establishTunnel(): Boolean {
        val blocked = Prefs.blocked(this)
        if (blocked.isEmpty()) return false

        val builder = Builder()
            .setSession("Data Saver")
            .setBlocking(true)
            .addAddress("10.255.0.2", 32)
            .addAddress("fd00:1:2:3::2", 128)
            .addRoute("0.0.0.0", 0)   // send all IPv4 from blocked apps into the tunnel
            .addRoute("::", 0)        // and all IPv6, otherwise it would leak past the block

        var added = 0
        for (pkg in blocked) {
            try {
                builder.addAllowedApplication(pkg)
                added++
            } catch (e: PackageManager.NameNotFoundException) {
                // app was uninstalled; skip it
            }
        }
        if (added == 0) return false

        val pfd = builder.establish() ?: return false  // null = VPN permission not granted
        tun = pfd

        // Read and throw away everything the blocked apps try to send.
        drainThread = Thread({
            val input = FileInputStream(pfd.fileDescriptor)
            val buf = ByteArray(32767)
            try {
                while (true) {
                    if (input.read(buf) < 0) break
                }
            } catch (e: Exception) {
                // tunnel closed; thread ends
            }
        }, "datasaver-drain").also { it.start() }

        return true
    }

    private fun teardown() {
        try { tun?.close() } catch (e: Exception) { }  // closing unblocks the drain thread
        tun = null
        drainThread = null
    }

    private fun shutdown() {
        unregisterNetworkCallback()
        teardown()
        Prefs.setBlockingOn(this, false)
        stopSelf()
    }

    override fun onRevoke() {
        // User turned the VPN off from system settings, or another VPN took over.
        unregisterNetworkCallback()
        teardown()
        Prefs.setBlockingOn(this, false)
        super.onRevoke()
    }

    override fun onDestroy() {
        unregisterNetworkCallback()
        teardown()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.example.datasaver.STOP"
    }
}
