package com.example.datasaver

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar

class MainActivity : Activity() {

    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun render() {
        root.removeAllViews()
        root.addView(label("Data Saver", 24f, bold = true))

        if (!UsageRepository.hasUsageAccess(this)) {
            root.addView(label("Allow usage access so the app can show which apps use your mobile data. Nothing leaves your phone."))
            root.addView(Button(this).apply {
                text = "Grant usage access"
                setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            })
            return
        }

        // Usage since the 1st of this month (mobile data only).
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val usage = UsageRepository.queryMobileUsage(this, cal.timeInMillis, System.currentTimeMillis())
        val total = usage.sumOf { it.totalBytes }
        val background = usage.sumOf { it.backgroundBytes }

        root.addView(label("This month on mobile data: ${fmt(total)}", 18f))
        if (total > 0) {
            val pct = background * 100 / total
            root.addView(label("Used in the background: ${fmt(background)} ($pct%)"))
        }

        val blockingOn = Prefs.isBlockingOn(this)
        root.addView(Button(this).apply {
            text = if (blockingOn) "Stop blocking" else "Start blocking selected apps"
            setOnClickListener { if (blockingOn) stopBlocking() else requestStart() }
        })
        root.addView(Switch(this).apply {
            text = "Only block on mobile data (apps work normally on Wi-Fi)"
            isChecked = Prefs.mobileOnly(this@MainActivity)
            setOnCheckedChangeListener { _, on ->
                Prefs.setMobileOnly(this@MainActivity, on)
                if (Prefs.isBlockingOn(this@MainActivity)) startBlocking()
            }
        })
        root.addView(Button(this).apply {
            text = "Select video apps (YouTube, Facebook, TikTok)"
            setOnClickListener { selectVideoApps() }
        })
        root.addView(Button(this).apply {
            text = "Data-saving guide"
            setOnClickListener { startActivity(Intent(this@MainActivity, GuideActivity::class.java)) }
        })
        root.addView(label("Apps selected for blocking: ${Prefs.blocked(this).size}", 12f))
        root.addView(label("Toggle an app below to block or unblock it.", 12f))

        for (app in usage.take(40)) {
            root.addView(row(app))
        }
    }

    private fun row(app: AppUsage): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 16, 0, 16)
        }
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        info.addView(label(app.label, 16f, bold = true))
        info.addView(label("${fmt(app.totalBytes)} total, ${fmt(app.backgroundBytes)} background", 12f))
        row.addView(info)

        val pkg = app.packageName
        if (pkg != null && pkg != packageName) {
            row.addView(Switch(this).apply {
                isChecked = Prefs.blocked(this@MainActivity).contains(pkg)
                setOnCheckedChangeListener { _, on ->
                    Prefs.setBlocked(this@MainActivity, pkg, on)
                    if (Prefs.isBlockingOn(this@MainActivity)) startBlocking() // apply the change now
                }
            })
        }
        return row
    }


    private fun selectVideoApps() {
        var found = 0
        for (pkg in VIDEO_PACKAGES) {
            try {
                packageManager.getPackageInfo(pkg, 0)
                Prefs.setBlocked(this, pkg, true)
                found++
            } catch (e: PackageManager.NameNotFoundException) {
                // not installed on this phone
            }
        }
        val msg = if (found > 0) "Selected $found video app(s)" else "No video apps from the list were found"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        if (found > 0 && Prefs.isBlockingOn(this)) startBlocking()
        render()
    }

    // --- Blocking control -------------------------------------------------

    private fun requestStart() {
        val intent = VpnService.prepare(this)   // null if permission was already granted
        if (intent != null) startActivityForResult(intent, REQ_VPN) else startBlocking()
    }

    @Deprecated("Fine for a skeleton; move to the Activity Result API later")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN && resultCode == RESULT_OK) startBlocking()
    }

    private fun startBlocking() {
        Prefs.setBlockingOn(this, true)
        startService(Intent(this, BlockerVpnService::class.java))
        root.postDelayed({ render() }, 300)
    }

    private fun stopBlocking() {
        startService(Intent(this, BlockerVpnService::class.java).setAction(BlockerVpnService.ACTION_STOP))
        Prefs.setBlockingOn(this, false)
        root.postDelayed({ render() }, 300)
    }

    // --- Small helpers ----------------------------------------------------

    private fun label(text: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 8, 0, 8)
    }

    private fun fmt(bytes: Long): String = when {
        bytes >= 1L shl 30 -> "%.2f GB".format(bytes / 1073741824.0)
        bytes >= 1L shl 20 -> "%.1f MB".format(bytes / 1048576.0)
        else -> "${bytes / 1024} KB"
    }

    companion object {
        private const val REQ_VPN = 1

        // Package names differ by version and region; only the ones installed are selected.
        private val VIDEO_PACKAGES = listOf(
            "com.google.android.youtube",
            "com.google.android.apps.youtube.mango",
            "com.facebook.katana",
            "com.facebook.lite",
            "com.zhiliaoapp.musically",
            "com.ss.android.ugc.trill"
        )
    }
}
