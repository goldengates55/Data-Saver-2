package com.example.datasaver

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.net.ConnectivityManager
import android.os.Process

data class AppUsage(
    val uid: Int,
    val packageName: String?,   // null for special entries (tethering, removed apps, system uids)
    val label: String,
    val foregroundBytes: Long,  // used while the app was on screen
    val backgroundBytes: Long   // used while the app was in the background
) {
    val totalBytes get() = foregroundBytes + backgroundBytes
}

object UsageRepository {

    fun hasUsageAccess(ctx: Context): Boolean {
        val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.unsafeCheckOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Mobile-data (SIM) usage per app between startMs and endMs, biggest first. Wi-Fi is excluded. */
    fun queryMobileUsage(ctx: Context, startMs: Long, endMs: Long): List<AppUsage> {
        val nsm = ctx.getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        val fg = HashMap<Int, Long>()
        val bg = HashMap<Int, Long>()

        val stats = nsm.querySummary(ConnectivityManager.TYPE_MOBILE, null, startMs, endMs)
        val bucket = NetworkStats.Bucket()
        try {
            while (stats.hasNextBucket()) {
                stats.getNextBucket(bucket)
                val bytes = bucket.rxBytes + bucket.txBytes
                val target = if (bucket.state == NetworkStats.Bucket.STATE_FOREGROUND) fg else bg
                target[bucket.uid] = (target[bucket.uid] ?: 0L) + bytes
            }
        } finally {
            stats.close()
        }

        val pm = ctx.packageManager
        return (fg.keys + bg.keys).map { uid ->
            val pkg = pm.getPackagesForUid(uid)?.firstOrNull()  // shared-UID apps: first package only
            val label = when {
                uid == NetworkStats.Bucket.UID_REMOVED -> "Uninstalled apps"
                uid == NetworkStats.Bucket.UID_TETHERING -> "Hotspot / tethering"
                pkg != null -> try {
                    pm.getApplicationInfo(pkg, 0).loadLabel(pm).toString()
                } catch (e: Exception) { pkg }
                else -> "System ($uid)"
            }
            AppUsage(uid, pkg, label, fg[uid] ?: 0L, bg[uid] ?: 0L)
        }.sortedByDescending { it.totalBytes }
    }
}
