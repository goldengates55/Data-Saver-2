package com.example.datasaver

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class GuideActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        scroll.addView(root)
        setContentView(scroll)

        root.addView(tv("Data-saving guide", 24f, true))
        root.addView(tv("Video is where most mobile data goes. These settings usually save the most. Menu names change between app versions, so look for similar wording.", 14f, false))

        root.addView(tv("Android", 18f, true))
        root.addView(tv("Turn on Data Saver, and restrict background data for apps you do not need.", 14f, false))
        root.addView(btn("Open Android data settings") { openDataSettings() })

        root.addView(tv("YouTube", 18f, true))
        root.addView(tv("- Settings, Video quality preferences, On mobile networks: Data saver\n- Turn off autoplay\n- Download videos on Wi-Fi at low quality, then watch offline", 14f, false))
        root.addView(btn("Open YouTube app info") { openAppInfo("com.google.android.youtube") })

        root.addView(tv("Facebook", 18f, true))
        root.addView(tv("- Settings and privacy, Settings, Media (or Data Saver): set video autoplay to Wi-Fi only or Never\n- Facebook Lite uses far less data than the full app", 14f, false))
        root.addView(btn("Open Facebook app info") { openAppInfo("com.facebook.katana") })

        root.addView(tv("TikTok", 18f, true))
        root.addView(tv("- Settings and privacy: look for Data Saver, and turn on any option that limits video preloading\n- Watch on Wi-Fi when you can", 14f, false))
        root.addView(btn("Open TikTok app info") { openAppInfo("com.zhiliaoapp.musically") })

        root.addView(tv("For all video apps", 18f, true))
        root.addView(tv("- Big downloads on Wi-Fi or a cheap night bundle\n- Lower quality saves the most: 240p uses roughly a fifth of the data of 720p\n- In this app, use Select video apps to block them on mobile data and keep them working on Wi-Fi", 14f, false))
    }

    private fun tv(text: String, size: Float, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(0, 12, 0, 12)
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
    }

    private fun openAppInfo(pkg: String) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open settings for this app", Toast.LENGTH_LONG).show()
        }
    }

    private fun openDataSettings() {
        try {
            startActivity(Intent("android.settings.DATA_USAGE_SETTINGS"))
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            } catch (e2: Exception) {
                Toast.makeText(this, "Could not open data settings", Toast.LENGTH_LONG).show()
            }
        }
    }
}
