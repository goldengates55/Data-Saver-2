# Data Saver v0.2

Android app that shows which apps use your mobile data and can block chosen apps
on mobile data (they keep working on Wi-Fi). No server, no INTERNET permission.

Build: the workflow in .github/workflows/build.yml unpacks datasaver.zip, builds the
debug APK and publishes it under Releases.
